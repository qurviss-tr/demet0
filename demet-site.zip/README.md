# Demet için doğum günü sitesi

## GitHub Pages ile yayınlama
1. github.com'da yeni bir depo (repository) aç, örneğin `demet`.
2. Bu klasördeki **her şeyi** (index.html, images klasörü, .nojekyll) depoya yükle: Add file > Upload files.
3. Depoda Settings > Pages > Source: **Deploy from a branch** > Branch: `main` / `(root)` > Save.
4. 1-2 dakika sonra adres hazır: `https://KULLANICIADIN.github.io/demet/`

Fotoğrafları değiştirmek için `images/` içindeki dosyaların üzerine aynı isimle yaz.
